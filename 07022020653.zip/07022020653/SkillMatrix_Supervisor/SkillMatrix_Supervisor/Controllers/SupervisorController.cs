﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Data.Entity;
using System.Web.Script.Serialization;
using System.Text;
using SkillMatrix_Supervisor.Infrastructure;


namespace SkillMatrix_Supervisor.Controllers
{
    [CustomAuthenticationFilter]
    [CustomAuthorizeFilter(Roles:"Supervisor")]
    [Authorize(Roles = "Supervisor")]
    public class SupervisorController : Controller
    {
        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();
        // GET: /Supervisor/
        public ActionResult Index()
        {
            MasterViewModel model = new MasterViewModel();
            foreach (var Employee in db.Tbl_EmployeeMaster)
            {
                model.Tbl_EmployeeMaster.Add(new SelectListItem { Text = Employee.EmployeeName, Value = Employee.EmpID });
            }
            //foreach (var Category in db.Tbl_Category)
            //{
            //    model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
            //}
            return View(model);

        }
        [HttpPost]
        [CustomAuthorizeFilter(Roles: "Supervisor")]
        [Authorize(Roles = "Supervisor")]
        public ActionResult Index(string Category_ID, string Skill_ID, byte? Score_ID, string EmpID)
        {
            string Supervisor = Convert.ToString(Session["UserName"]);


            MasterViewModel model = new MasterViewModel();

            foreach (var Employee in db.Tbl_EmployeeMaster)
            {
                model.Tbl_EmployeeMaster.Add(new SelectListItem { Text = Employee.EmployeeName, Value = Employee.EmpID });

            }

            if (EmpID != "")
            {
                var EmpDetails = (from Emp in db.Tbl_EmployeeMaster
                                  where Emp.EmpID == EmpID
                                  select Emp).ToList();
                foreach (var Id in EmpDetails)
                {
                    model.Tbl_EmployeeMaster.Add(new SelectListItem { Text = Id.EmpID, Value = Id.EmployeeName });
                }
            }


            if (EmpID != "")
            {

                foreach (var Category in db.Tbl_Category)
                {
                    model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
                }
            }

            if (Category_ID != "")
            {
                var Skills = (from Skill in db.Tbl_Skills
                              where Skill.Category_ID == Category_ID
                              select Skill).ToList();
                foreach (var Skill in Skills)
                {
                    model.Tbl_Skills.Add(new SelectListItem { Text = Skill.Skill_Name, Value = Skill.Skill_ID });
                }
                if (Skill_ID != null)
                {

                    var Scores = (from Score in db.Tbl_Score_Description

                                  select Score).ToList();
                    foreach (var Score in Scores)
                    {
                        model.Tbl_Score_Description.Add(new SelectListItem { Text = Score.Score_ID.ToString(), Value = Score.Score_ID.ToString() });
                    }

                }
                if (Score_ID != null)
                {

                    var Scoress = (from Score1 in model.Tbl_Score_Description
                                   where Score1.Value == Score_ID.ToString()
                                   select Score1).ToList();


                }
                if (Category_ID != "" && Skill_ID != "" && Score_ID != null && EmpID != "")
                {
                    InserScores(Category_ID, Skill_ID, Score_ID, EmpID);

                }







            }
            //if (Category_ID != "")
            //{
            //    var scores = (from Score in db.Tbl_Score_Description select Score).ToList();

            //    foreach (var Score in scores)
            //    {
            //        model.Tbl_Score_Description.Add(new SelectListItem { Text = Score.Score_ID.ToString(), Value = Score.Score_ID.ToString() });
            //    }
            //}

            return View(model);

        }
        public ActionResult getEmployees(string sidx, string sord, int page, int rows, string searchString)
        {
            //#1 Create Instance of DatabaseContext class for Accessing Database.  

            string Supervisor = Convert.ToString(Session["UserName"]);
            //#2 Setting Paging  
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;

            //#3 Linq Query to Get Customer  
            var Results = (from r in db.Tbl_Role
                           join ep in db.Tbl_EmployeeMaster on r.RoleID equals ep.Role




                           select new
                           {
                               ep.EmpID,
                               ep.EmployeeName,
                               ep.DOJ,
                               ep.Designation,
                               ep.MailID,
                               ep.ReportingPerson,
                               r.Role,
                               r.RoleID,



                           });

            //#4 Get Total Row Count  
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

            //#5 Setting Sorting  
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            //based on login employeeview
            if (!string.IsNullOrEmpty(Supervisor))
            {
                Results = Results.Where(m => m.ReportingPerson == Supervisor);


            }

            //#6 Setting Search  
            if (!string.IsNullOrEmpty(searchString))
            {
                Results = Results.Where(m => m.EmpID == searchString);
            }
            //#7 Sending Json Object to View.  
            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = Results
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);

        }
        public JsonResult employeesscores(string sidx, string sord, int page, int rows, string searchString)
        {
            //#1 Create Instance of DatabaseContext class for Accessing Database.  


            //#2 Setting Paging  
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;

            //#3 Linq Query to Get Customer  
            var Result = (from es in db.Tbl_Employee_Score
                          join ct in db.Tbl_Category on es.Category_Name equals ct.Category_ID
                          join sk in db.Tbl_Skills on es.Skill_Name equals sk.Skill_ID

                          select new
                          {
                              es.EmpID,
                              ct.Category_Name,
                              sk.Skill_Name,
                              es.Score_Rating,

                          });

            //#4 Get Total Row Count  
            int totalRecords = Result.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

            //#5 Setting Sorting  
            if (sord.ToUpper() == "DESC")
            {
                Result = Result.OrderByDescending(s => s.EmpID);
                Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Result = Result.OrderBy(s => s.EmpID);
                Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
            }
            //based on login employeeview
            //if (!string.IsNullOrEmpty(Supervisor_ID))
            //{
            //    Result = Result.Where(m => m.ReportingPerson == Supervisor_ID);
            //}
            //#6 Setting Search  
            if (!string.IsNullOrEmpty(searchString))
            {
                Result = Result.Where(m => m.EmpID == searchString);
            }
            //#7 Sending Json Object to View.  
            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = Result
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);

        }


        public JsonResult InserScores(string Category_ID, string Skill_ID, byte? Score_ID, string EmpID)
        {

            StringBuilder msg = new StringBuilder();
            try
            {
                if (ModelState.IsValid)
                {
                    Tbl_Employee_Score obj = new Tbl_Employee_Score();
                    obj.EmpID = EmpID;
                    obj.Category_Name = Category_ID;
                    obj.Skill_Name = Skill_ID;
                    obj.Score_Rating = Score_ID;
                    db.Tbl_Employee_Score.Add(obj);

                    db.SaveChanges();
                    ModelState.Clear();

                    return Json("Saved Successfully", JsonRequestBehavior.AllowGet);

                }
                else
                {
                    var errorList = (from item in ModelState
                                     where item.Value.Errors.Any()
                                     select item.Value.Errors[0].ErrorMessage).ToList();

                    return Json(errorList, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                var errormessage = "Error occured: " + ex.Message;

                return Json(errormessage, JsonRequestBehavior.AllowGet);
            }

        }

        public string EditScores(Tbl_Employee_Score Employee)
        {
            string msg;
            try
            {

                if (ModelState.IsValid)
                {

                    db.Entry(Employee).State = EntityState.Modified;
                    db.SaveChanges();
                    msg = "Saved Successfully";

                }
                else
                {
                    msg = "Some Validation ";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }



        //    [HttpPost]
        //    public JsonResult AddScores(  customers)
        //    {
        //        StringBuilder msg = new StringBuilder();
        //        try
        //        {
        //            if (ModelState.IsValid)
        //            {
        //                using (DatabaseContext db = new DatabaseContext())
        //                {
        //                    db.Customers.Add(customers);
        //                    db.SaveChanges();
        //                    return Json("Saved Successfully", JsonRequestBehavior.AllowGet);
        //                }
        //            }
        //            else
        //            {
        //                var errorList = (from item in ModelState
        //                                 where item.Value.Errors.Any()
        //                                 select item.Value.Errors[0].ErrorMessage).ToList();

        //                return Json(errorList, JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            var errormessage = "Error occured: " + ex.Message;
        //            return Json(errormessage, JsonRequestBehavior.AllowGet);
        //        }

        //}
    }
}
