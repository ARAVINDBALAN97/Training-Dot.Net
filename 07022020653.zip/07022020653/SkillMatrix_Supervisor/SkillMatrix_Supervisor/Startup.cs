﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SkillMatrix_Supervisor.Startup))]
namespace SkillMatrix_Supervisor
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
