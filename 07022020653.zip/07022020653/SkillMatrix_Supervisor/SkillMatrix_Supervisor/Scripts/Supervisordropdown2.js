﻿$(function () {
    if ($("#Category_ID option").length > 1) {
        $("#Category_ID").removeAttr("disabled");
    }
    if ($("#Skill_ID option").length > 1) {
        $("#Skill_ID").removeAttr("disabled");
    }
    if ($("#Score_ID option").length >= 0) {
        $("#Score_ID").removeAttr("disabled");
    }



    if ($("#EmpID").val != "" && $("#Category_ID").val() != "" && $("#Skill_ID").val() != "" && $("#Score_ID").val() !="") {
        var message = "EmpID: " + $("#EmpID option:selected").text();
        message += "\nCategory: " + $("#Category_ID option:selected").text();
        message += "\nSkill: " + $("#Skill_ID option:selected").text();
        message += "\nScore: " + $("#Score_ID option:selected").text();
        alert(message);
    }
});

//$(function () {
//    if ($("#StateId option").length > 1) {
//        $("#StateId").removeAttr("disabled");
//    }

//    if ($("#CityId option").length > 1) {
//        $("#CityId").removeAttr("disabled");
//    }

//    if ($("#CountryId").val() != "" && $("#StateId").val() != "" && $("#CityId").val() != "") {
//        var message = "Country: " + $("#CountryId option:selected").text();
//        message += "\nState: " + $("#StateId option:selected").text();
//        message += "\nCity: " + $("#CityId option:selected").text();
//        alert(message);
//    }
//});

//$(document).ready(function () {
//    $("#skill").change(function () {
//        $("#score").empty();
//        $.ajax({
//            type: 'POST',
//            url: '@Url.Action("GETSkill")',
//            dataType: 'json',
//            data: { id1: $("#skill").val() },
//            success: function (scoredata) {
//                $.each(scoredata, function (i, score) {
//                    $("#score").append('<option value="' + score.Value + '">'
//                        + score.Text + '<option>');
//                });
//            },
//            error: function (ex) {
//                alert("failed" + ex);
//            }
//        });
//        return false;
//    })
//});
