﻿
$(document).ready(
        function () {
            if ($("#Skill_ID option").length > 1) {
                $("#Skill_ID").removeAttr("disabled");
            }



            if ($("#Category_ID").val() != "" && $("#Skill_ID").val() != "") {
                var message = "Category: " + $("#Category_ID option:selected").text();
                message += "\nSkill: " + $("#Skill_ID option:selected").text();

                alert(message);
            }
        });
