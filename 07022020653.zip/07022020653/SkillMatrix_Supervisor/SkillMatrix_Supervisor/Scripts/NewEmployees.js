﻿

//$('#btnSave').click(superviser);
//});
//function superviser() {


$(document).ready(function () {
   
    $("#jqGrid").jqGrid
       ({
           url: "/Employee_Supervisor/getEmployees",
           datatype: 'json',
           mtype: 'Get',
           //table header name   

           colNames: ['EmpID', 'EmployeeName ', 'DOJ', 'MailID', 'Designation ', 'ReportingPerson', 'Role', 'RoleID'],
           //colModel takes the data from controller and binds to grid   
           colModel: [
        {
            key: true,
            hidden: false,
            name: 'EmpID',
            index: 'EmpID',
            editable: true
        }, {
            key: false,
            name: 'EmployeeName',
            index: 'EmployeeName',
            editable: true
        }, {
            key: false,
            name: 'DOJ',
            index: 'DOJ',
            editable: true,
            formatter: 'date', formatoptions: { newformat: 'd/m/Y' }
        }, {
            key: true,
            hidden: false,
            name: 'MailID',
            index: 'MailID',
            editable: true
        }, {
            key: false,
            name: 'Designation',
            index: 'Designation',
            editable: true
        }, {
            hidden: true,
            key: false,
            name: 'ReportingPerson',
            index: 'ReportingPerson',
            editable: true,

        }, {
            hidden: false,
            key: false,
            name: 'Role',
            index: 'Role',
            editable: false,

        }, {
            hidden: true,
            key: false,
            name: 'RoleID',
            index: 'RoleID',
            editable: true,

        }],

           pager: jQuery('#jqGridView'),
           rowNum: 10,
           rowList: [10, 20, 30, 40],
           height: '100%',
           viewrecords: true,
           caption: 'Employee Details',
           emptyrecords: 'No records to display',
           jsonReader:
          {
              root: "rows",
              page: "page",
              total: "total",
              records: "records",
              repeatitems: false,
              Id: "0"
          },
           autowidth: true,
           multiselect: false
           //pager-you have to choose here what icons should appear at the bottom  
           //like edit,create,delete icons  
       }).navGrid('#jqGridView',
{
    edit: true,
    add: true,
    del: true,
    search: false,
    refresh: true
}, {
    // edit options  
    zIndex: 100,
    url: '/Employee_Supervisor/EditEmployee',
    closeOnEscape: true,
    closeAfterEdit: true,
    recreateForm: true,
    afterComplete: function (response) {
        if (response.responseText) {
            alert(response.responseText);
        }
    }
}, {
    // add options  
    zIndex: 100,
    url: "/Sample/Create",
    closeOnEscape: true,
    closeAfterAdd: true,
    afterComplete: function (response) {
        if (response.responseText) {
            alert(response.responseText);
        }
    }
}, {
    // delete options  
    url: "/Sample/Delete",
    closeOnEscape: true,
    closeAfterDelete: true,
    recreateForm: true,
    msg: "Are you sure you want to delete this task?",
    afterComplete: function (response) {
        if (response.responseText) {
            alert(response.responseText);
        }
    }
})
}

);
//;