﻿


//$('#btnSave').click(function () {
//    $.ajax({
//        url: "/Home/SaveDetailedInfo",
//        type: "POST",
//        data: JSON.stringify({ 'Options': someData }),
//        dataType: "json",
//        traditional: true,
//        contentType: "application/json; charset=utf-8",
//        success: function (data) {
//            if (data.status == "Success") {
//                alert("Done");
//            } else {
//                alert("Error occurs on the Database level!");
//            }
//        },
//        error: function () {
//            alert("An error has occured!!!");
//        }
//    });
//});

//$('#btnSave').click(superviser);
//});
//function superviser() {


    $(document).ready(function () {
        $('#Score').click(superviser);
    });
    function superviser() {




        $("#jqGrid1").jqGrid
               ({
                   url: "/Employee_Supervisor/employeesscores",
                   datatype: 'json',
                   mtype: 'Get',
                   //table header name   

                   colNames: ['EmpID', 'Category_Name ', 'Skill_Name', 'Score_Rating', 'ReportingPerson'],
                   //colModel takes the data from controller and binds to grid   
                   colModel: [
                {
                    key: true,
                    hidden: false,
                    name: 'EmpID',
                    index: 'EmpID',
                    editable: true
                }, {
                    key: false,
                    name: 'Category_Name',
                    index: 'Category_Name',
                    editable: true
                }, {
                    key: false,
                    name: 'Skill_Name',
                    index: 'Skill_Name',
                    editable: true,

                }, {
                    key: true,
                    hidden: false,
                    name: 'Score_Rating',
                    index: 'Score_Rating',
                    editable: true
                }, {
                    hidden: true,
                    key: false,
                    name: 'ReportingPerson',
                    index: 'ReportingPerson',
                    editable: true,

                }],

                   pager: jQuery('#jqGridView'),
                   rowNum: 10,
                   rowList: [10, 20, 30, 40],
                   height: '100%',
                   viewrecords: true,
                   caption: 'Employee Score',
                   emptyrecords: 'No records to display',
                   jsonReader:
                  {
                      root: "rows",
                      page: "page",
                      total: "total",
                      records: "records",
                      repeatitems: false,
                      Id: "0"
                  },
                   autowidth: true,
                   multiselect: false
                   //pager-you have to choose here what icons should appear at the bottom  
                   //like edit,create,delete icons  
               }).navGrid('#jqGridView',
        {
            edit: true,
            add: true,
            del: true,
            search: false,
            refresh: true
        }, {
            // edit options  
            zIndex: 100,
            url: '/Sample/Edit',
            closeOnEscape: true,
            closeAfterEdit: true,
            recreateForm: true,
            afterComplete: function (response) {
                if (response.responseText) {
                    alert(response.responseText);
                }
            }
        }, {
            // add options  
            zIndex: 100,
            url: "/Sample/Create",
            closeOnEscape: true,
            closeAfterAdd: true,
            afterComplete: function (response) {
                if (response.responseText) {
                    alert(response.responseText);
                }
            }
        }, {
            // delete options  
            url: "/Sample/Delete",
            closeOnEscape: true,
            closeAfterDelete: true,
            recreateForm: true,
            msg: "Are you sure you want to delete this task?",
            afterComplete: function (response) {
                if (response.responseText) {
                    alert(response.responseText);
                }
            }
        }
        )
    }
        

    
