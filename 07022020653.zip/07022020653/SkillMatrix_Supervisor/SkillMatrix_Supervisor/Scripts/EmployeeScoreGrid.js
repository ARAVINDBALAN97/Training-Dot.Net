


$(document).ready(function () {

   
    //debugger;
    $("#gridEmployeeScore").jqGrid
    ({

        url: "/Admin/GetEmployeeScores",
        datatype: 'json',
        mtype: 'Get',
        //table�header�name���
        colNames: ['EmpID','EmployeeName','Designation','ReportingPerson','Category_Name', 'Skill_Name', 'Score_Rating'],
        //colModel�takes�the�data�from�controller�and�binds�to�grid���
        colModel: [
        {
            key: true,
            hidden: false,
            name: 'EmpID',
            index: 'EmpID',
            editable: true
        }, {
            key: false,
            name: 'EmployeeName',
            index: 'EmployeeName',
            editable: true
        }, {
            key: false,
            name: 'Designation',
            index: 'Designation',
            editable: true
        }, {
            key: false,
            name: 'ReportingPerson',
            index: 'ReportingPerson',
            editable: true
        }, {
            key: false,
            name: 'Category_Name',
            index: 'Category_Name',
            editable: true
        },
         {
             key: false,
             hidden: false,
             name: 'Skill_Name',
             index: 'Skill_Name',
             editable: true
         }, {
             key: false,
             name: 'Score_Rating',
             index: 'Score_Rating',
             editable: true
         }],

        pager: jQuery('#pagerEmployeeScore'),
        rowNum: 10,
        rowList: [10, 20, 30, 40],
        height: '100%',
        viewrecords: true,
        caption: 'Employees Score',
        emptyrecords: 'No�records�to�display',
        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
        multiselect: false
        //pager-you�have�to�choose�here�what�icons�should�appear�at�the�bottom��
        //like�edit,create,delete�icons��
    }).navGrid('#pagerEmployeeScore',
    {
        edit: false,
        add: false,
        del: false,
        search: false,
        refresh: true
    }, {
        //�edit�options��
        zIndex: 100,
        url: '/Admin/EditEmployeeScores',
        closeOnEscape: true,
        closeAfterEdit: true,
        recreateForm: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�add�options��
        zIndex: 100,
        url: "/Admin/CreateEmployeeScores",
        closeOnEscape: true,
        closeAfterAdd: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�delete�options��
        zIndex: 100,
        url: "/Admin/DeleteEmployeeScores",
        closeOnEscape: true,
        closeAfterDelete: true,
        recreateForm: true,
        msg: "Are�you�sure�you�want�to�delete�this�task?",
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }

    });
});






