﻿

$(document).ready

           // This function gets called whenever an edit dialog is opened
           (function populateCities() {
               // first of all update the city based on the country
               updateCityCallBack($("#Name").val());
               // then hook the change event of the country dropdown so that it updates cities all the time
               $("#Name").bind("change", function (e) { updateCityCallBack($("#Name").val()); });
           });

function updateCityCallBack(country) {               
    $("#City").html("<option value=''>Loading cities...</option>").attr("disabled", "disabled");
    $.ajax({
        url: '@Url.Action("GetCitiesJson","grid")' + "?country=" + country,
        type: "GET",
        success: function(citiesJson) {
            var cities = eval(citiesJson);
            var citiesHtml = "";
            $(cities).each(function(i, option) {
                citiesHtml += '<option value="' + option + '">' + option + '</option>';
            });                       
            $("#City").removeAttr("disabled").html(citiesHtml);
        }
    });
}
       
